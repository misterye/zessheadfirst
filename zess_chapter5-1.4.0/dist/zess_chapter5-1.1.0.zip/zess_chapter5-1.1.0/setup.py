from distutils.core import setup

setup(
    name = 'zess_chapter5',
    version = '1.1.0',
    py_modules = ['zess_chapter5'],
    author = 'zess',
    author_email = 'zess1982@126.com',
    url = 'http://satellite.sinaapp.com/',
    description = 'Parsing data.',
    )
