from distutils.core import setup

setup(
    name = 'zess_chapter7',
    version = '1.0.0',
    py_modules = ['zess_chapter7'],
    author = 'zess',
    author_email = 'zess1982@126.com',
    url = 'http://satellite.sinaapp.com/',
    description = 'New model: athletemodel.',
    )
