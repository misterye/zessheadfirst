from distutils.core import setup

setup(
    name = 'zess_chapter3',
    version = '1.0.0',
    py_modules = ['zess_chapter3'],
    author = 'zess',
    author_email = 'zess1982@126.com',
    url = 'http://satellite.sinaapp.com/',
    description = 'Manipulate with files.',
    )
