from distutils.core import setup

setup(
    name = 'zess_nester',
    version = '1.3.0',
    py_modules = ['zess_nester'],
    author = 'zess',
    author_email = 'zess1982@126.com',
    url = 'http://satellite.sinaapp.com/',
    description = 'A functional printer of nested lists of zess',
    )
